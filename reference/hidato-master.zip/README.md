# hidato
Introduction to Optimization final project - GA for hidata

## Usage

```python
python3 main.py --n 10 --a 0.5 --g 1500 --m 1 --r 10
```

